<html>
<head>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
</head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.card-counter{
    box-shadow: 2px 2px 10px #DADADA;
    margin: 5px;
    padding: 20px 10px;
    background-color: #fff;
    height: 400px;
	width: 600px;
    border-radius: 5px;
    transition: .3s linear all;
  }

  .card-counter:hover{
    box-shadow: 4px 4px 20px #DADADA;
    transition: .3s linear all;
  }

  .card-counter.primary{
    background-color: #007bff;
    color: #FFF;
  }

  .card-counter.danger{
    background-color: #ef5350;
    color: #FFF;
  }  

  .card-counter.success{
    background-color: #66bb6a;
    color: #FFF;
  }  

  .card-counter.info{
    background-color: #26c6da;
    color: #FFF;
  }  

  .card-counter i{
    font-size: 5em;
    opacity: 0.2;
  }

  .card-counter .count-numbers{
    position: absolute;
    right: 35px;
    top: 20px;
    font-size: 32px;
    display: block;
  }

  .card-counter .count-name{
    position: absolute;
    right: 35px;
    top: 65px;
    font-style: italic;
    text-transform: capitalize;
    opacity: 0.5;
    display: block;
    font-size: 18px;
  }
  
  .layer {
    background-color: rgba(248, 247, 216, 0.7);
}
.card-counter{background-color: #D7CB99;}
</style>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
<body>
<div class="w3-display-container">
  <img src="baby.jpeg" class="layer" alt="Orangutan" height=600 width=100%>
  <div class="w3-display-topleft w3-container">
  <font color="white"><?php include "Nav-bar/index.html"; ?></font>
  <div class="container"><br>
      <div class="card-counter">
	  <center><font color="white"><h1>OUR MISSION</h1></center><br>You are just few steps away to save Environment.
	  <br><div class="progress" style="height: 30px;">
  <div class="progress-bar progress-bar-striped bg-warning progress-bar-animated" role="progressbar" style="width: 35%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
</div><br>
<h2> By Buying these palm oil free products you are saving 1 Orangutan </h2><br>
<center><h3><img src='http://2018.igem.org/wiki/images/e/e6/T--Tec-Chihuahua--EcoCoins.png' height=30 width=25>Also get great rewards <img src='http://2018.igem.org/wiki/images/e/e6/T--Tec-Chihuahua--EcoCoins.png' height=30 width=25></h3></center>
      </div>
  </div></div
</div>
<div class="container">
    
</div>
</body>
</html>
